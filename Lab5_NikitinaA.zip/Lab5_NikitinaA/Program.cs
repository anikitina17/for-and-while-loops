﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_NikitinaA
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.GetEncoding(1251);

            Console.Write("Введіть кількість елементів масиву: ");
            int a= int.Parse(Console.ReadLine());

            int[] arr = new int[a];
            Console.WriteLine("Введіть елементи масиву:");

            for (int i = 0; i < a; i++)
                arr[i] = int.Parse(Console.ReadLine());

            int count = 0;
            Console.WriteLine("\nПари, що мають спільний дільник більший за 1:");

            for (int i = 0; i < a; i++)
            {
                for (int j = i + 1; j < a; j++)
                {
                    int gcd = GCD(arr[i], arr[j]);
                    if (gcd > 1)
                    {
                        Console.WriteLine($"{arr[i]} і {arr[j]} (НСД = {gcd})");
                        count++;
                    }
                }
            }

            Console.WriteLine($"\nКількість таких пар: {count}");
        }

        static int GCD(int b, int c)
        {
            while (b != 0)
            {
                int temp = c % b;
                c = b;
                b = temp;
            }
            return Math.Abs(c);
        }
    }
}